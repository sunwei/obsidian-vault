+++
title = "你好 MDFriday"
cta_title = "探索 MDFriday"
cta_url = "https://mdfriday.com"
+++

# 恭喜你！

你刚刚使用MDFriday创建了你另一个网站。🎉

你的内容现在已经上线，准备与世界分享！
