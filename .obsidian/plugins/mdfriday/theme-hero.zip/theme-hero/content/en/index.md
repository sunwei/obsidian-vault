+++
title = "Hello MDFriday"
cta_title = "Explore MDFriday"
cta_url = "https://mdfriday.com"
+++

# Congratulations!

You've just created your another website with MDFriday. 🎉

Your content is now live and ready to be shared with the world!
