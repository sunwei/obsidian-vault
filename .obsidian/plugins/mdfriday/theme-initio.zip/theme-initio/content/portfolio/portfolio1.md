+++
title = "Sample title - big data solutions"
image = "images/s1.jpg"
weight = 1
+++

I don't think they tried to market it to the billionaire, spelunking, base-jumping crowd. i did the same thing to gandhi, he didn't eat for three weeks. i once heard a wise man say there are no perfect men.
