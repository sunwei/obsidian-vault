+++
title = "Download Source Code"
file = "https://github.com/mdfriday/theme-initio/archive/refs/heads/main.zip"
weigth = 2
+++

Another simple, nice-looking **call to action box**. Boxing is about respect. getting it for yourself, and taking it away from the other guy. no, this is mount everest.
