+++
title = "Download original template"
file = "downloads/banner_sun_full.jpeg.zip"
weight = 1
+++

A simple, nice-looking **call to action box**. Boxing is about respect. getting it for yourself, and taking it away from the other guy. no, this is mount everest.
