+++
title = "MDFriday"
date = "2024-10-25T12:00:00-00:00"
+++

## MDFriday 

Turn MD docs into website in minutes

![MDFriday](mdfriday.jpeg)