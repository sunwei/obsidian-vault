+++
type = "subheader"
title = ""
+++

Let me tell you something my friend. hope is a dangerous thing. hope can drive a man insane. you [measure](/about) yourself by the people who measure themselves by you. it only took me [six days](/sidebar-right).
