---
title: "MDFriday"
description: "Turn markdown docs into website, in minutes."
---

##### headline

Build Your SaaS Website

##### sub_headline

Create stunning, responsive websites that load instantly.
Built with Hugo and TailwindCSS for maximum performance and flexibility

##### primary_button_text

Get Started Free

##### primary_button_url

/

##### secondary_button_text

View Demo

##### secondary_button_url

/

##### hero_image

/images/hero-dashboard.svg