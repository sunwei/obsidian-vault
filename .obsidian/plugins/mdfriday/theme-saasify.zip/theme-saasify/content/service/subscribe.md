##### title

Subscribe to Newsletter

##### description

Get the latest posts delivered right to your inbox

##### action 

https://formspree.io/f/your-form-id

##### emailName

email

##### buttonText

Subscribe

##### placeholder

Enter your email

##### disclaimer

We respect your privacy. Unsubscribe at any time