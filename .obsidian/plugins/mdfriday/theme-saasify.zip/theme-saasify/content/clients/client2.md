+++
weight = 2
title = "Customer 2"
image = "/images/logos/customer-2.png"
+++

