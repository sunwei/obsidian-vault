+++
title = "linkedin"
url = "https://www.linkedin.com/in/nickname"
weight = 7
+++

Description
