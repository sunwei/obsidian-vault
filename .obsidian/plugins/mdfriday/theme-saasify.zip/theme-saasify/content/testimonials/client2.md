+++
weight = 2
name = "Sarah Johnson"
title = "Founder at WebFlow"
avatar = "/images/testimonial-1.svg"
+++

The combination of Hugo and TailwindCSS delivers lightning-fast performance. 
Our website loads instantly, which has significantly improved our conversion rates.
 